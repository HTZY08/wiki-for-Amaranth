"""Resonance engine Phase 1 package."""

__version__ = "0.1.0"
