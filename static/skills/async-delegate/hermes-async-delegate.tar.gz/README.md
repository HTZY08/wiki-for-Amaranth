# Hermes Async Delegate Skill

通过 Hermes Kanban 实现异步任务委派。

## 安装

```bash
# 复制 skill 到 Hermes 技能目录
cp -r software-development/delegate ~/.hermes/skills/software-development/
```

或从仓库克隆：

```bash
git clone <repo-url> /tmp/hermes-delegate
cp -r /tmp/hermes-delegate/software-development/delegate ~/.hermes/skills/software-development/
```

## 快速开始

1. 初始化 Kanban：`hermes kanban init`
2. 创建 worker profile：`hermes profile create worker --clone`
3. 更新 worker SOUL.md 为 `references/worker-SOUL.md` 的内容
4. 精简 worker .env（移除不必要的 API key）
5. 配置 kanban 参数（见 SKILL.md）

## 要求

- Hermes Agent ≥ 0.14.0
- Kanban 系统已启用
