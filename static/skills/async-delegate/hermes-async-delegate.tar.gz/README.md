# Hermes Async Delegate Skill

基于 Hermes Kanban 的异步任务委派系统。

## License

CC BY-NC-SA 4.0。仅供个人学习、研究、开发使用，禁止商用。

## 结构

```
async-delegate/
├── SKILL.md                  # 核心 skill
└── references/
    ├── README.md             # Profile 安装说明
    ├── worker-SOUL.md        # 通用 worker 模板
    └── ...
```

## 安装

```bash
cp -r async-delegate ~/.hermes/skills/
hermes kanban init
hermes profile create worker --clone
```

详见 `SKILL.md`。
