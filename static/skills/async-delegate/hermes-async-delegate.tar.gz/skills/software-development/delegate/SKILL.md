---
name: delegate
description: 通过 Hermes Kanban 实现异步任务委派——大任务(≥3步/需调研/>30s)拆解后交给后台特化 profile 执行，前台保持响应。小任务直接干。核心铁律：先创卡再回用户，禁止先调研。
version: 3.0.0
author: Amaranth
license: CC BY-NC-SA 4.0
metadata:
  hermes:
    tags: [delegate, async, kanban, orchestration, workflow]
    related_skills: [kanban-orchestrator, background-task-routing]
---

# Delegate — 异步任务委派系统

## 概述

基于 Hermes Kanban 的异步任务处理架构。将大任务拆解为子任务，通过 `kanban_create(assignee=<profile>)` 派发给对应的特化 profile 执行。前台立即回复用户，不阻塞。

**核心改进（2026-06-13）：前后台分离。** 不再使用 `delegate_task()`（同步阻塞），改用 Kanban（异步，不阻塞主线程）。

## 架构

```
用户 → 主 Agent（前台，永远在线）
         │ kanban_create() × N → 立即返回
         ↓
      Kanban Queue (SQLite)
         │ dispatcher（Hermes gateway 内部）每5秒轮询
         ↓
      worker profile（后台独立进程，完整 Hermes 工具集）
         │ 读卡片 → 执行 → 写产出
         │ kanban_comment() 记录进度
         │ kanban_complete() 完成
```

## 跨平台上下文

当用户同时在微信（WeChat）和 CLI 两个平台与你交互时，任务上下文不能混。

### 共享上下文文件

`/opt/data/workflow/context.md` 记录各平台当前任务：
- 每次会话首件事：读 context.md 看另一平台在做什么
- 用 `ctx "当前任务"` 更新本平台上下文
- 任务切换时更新

### 平台检测

```bash
if [ -n "$WEIXIN_ACCOUNT_ID" ]; then PLATFORM="weixin"; else PLATFORM="cli"; fi
```

`kanban-create.sh` 和 `ctx.sh` 已集成此检测，发卡片时自动记录来源平台。

### 动机：为什么不用 delegate_task

`delegate_task()` 是同步调用——主 agent 派发后必须等待所有子任务完成。这意味着：
- 用户在整个执行期间无法插话
- 多任务串行而非并行
- 子 agent 崩溃后整个链路卡死

Kanban 解决了这些问题：异步、持久化（SQLite）、支持依赖链（parents[]）、崩溃自动重试。

## 基础设施

### Kanban 配置

```yaml
# ~/.hermes/config.yaml 或主配置
kanban:
  dispatch_in_gateway: true
  dispatch_interval_seconds: 5          # 轮询间隔（默认60，改为5）
  failure_limit: 3                       # 失败重试次数（默认2）
  max_in_progress_per_profile: 3        # 每 profile 并发上限
  orchestrator_profile: 'default'       # 编排器 profile
  default_assignee: 'worker'            # 默认 worker profile
  dispatch_stale_timeout_seconds: 600   # ⚠️ 默认14400(4h)，必须改为600(10min)
```

### Worker Profile 配置

Worker profile 应克隆自主 profile，然后做三件事：

1. **精简 .env** — 移除所有不必要的 API key。worker 只需要执行必需的 key（如 DeepSeek、OpenRouter），不应持有 Tavily/Exa/GitHub 等第三方 key。使用最小权限原则。
2. **定制 SOUL.md** — 写入 worker 行为规范（见 `references/worker-SOUL.md`）
3. **设置 profile description** — `hermes profile describe worker --text "..."`，用于 kanban auto-decompose 路由

### 辅助脚本

创建脚本解决 shell 传参 body 换行符丢失问题：

```bash
#!/bin/bash
# Usage: cat task-body.txt | kanban-create.sh "Task Title" [assignee] [max-runtime]
BODY=$(cat)
TITLE="$1"
ASSIGNEE="${2:-worker}"
RUNTIME="${3:-10m}"
hermes kanban create "$TITLE" --body "$BODY" --assignee "$ASSIGNEE" --max-runtime "$RUNTIME"
```

### 可用 Worker Profile

| Profile | 专精 | 主模型 | 副模型 | 适用任务 |
|---------|------|-------|-------|---------|
| **worker** | 通用 | DeepSeek V4 Flash | — | 不明确分类的任务 |
| **compute** | 计算化学 | DeepSeek V4 Flash | Gemini 3.1 Pro | ORCA/xtb/docking |
| **code** | 编码 | DeepSeek V4 Flash | Claude Sonnet | 脚本/debug/架构 |
| **writer** | 写作 | Claude Sonnet | DeepSeek V4 Flash | 文档/翻译/润色 |
| **researcher** | 研究 | Gemini 3.1 Pro | DeepSeek V4 Flash | 文献/深度分析 |
| **image** | 生图 | API Yi chatgpt-image-latest | SiliconFlow Qwen-Image | 学术/配图/封面 |

特化 profile 的完整 SOUL.md 模板见 `references/compute-profile-SOUL.md`、`references/researcher-profile-SOUL.md` 和 `references/image-profile-SOUL.md`。

## 多层模型架构

特化 profile 采用双层模型分工，而非单一模型：

- **执行层**（DeepSeek V4 Flash）：快速响应、文件操作、命令执行、编码实现
- **分析层**（Gemini 3.1 Pro / Claude Sonnet）：深度分析、架构设计、内容质量把关

实现方式：worker 在 SOUL.md 中被指示在遇到复杂分析任务时，通过 `curl` 调用外部 API（API Yi / PackyAPI）完成分析，将结论用于指导执行。

这种模式避免了为"可能需要的分析能力"支付全时高端模型成本。

## 行为规则（核心，不可违反）

### 任务分类判定

收到任务后，用 2 句话判断是"大任务"还是"小任务"：

| 判定维度 | ✅ 走 kanban（后台） | ❌ 直接干（前台） |
|---------|--------------------|-----------------|
| 步骤数 | 3+ 步 | 1 步脚本就能搞定 |
| 是否需调研 | 需要搜索/分析/推理/设计 | 已知信息，直接回答 |
| 是否需持久产出 | 写文件、改配置、跑计算 | 纯回复 |
| 用户明确要求 | "后台跑"、"慢慢做"、"跑完告诉我" | "现在做"、"别后台" |
| 耗时预估 | >30 秒 | <5 秒 |

**边界案例判断：不确定时默认走 kanban。** 先创卡再回用户，永远比先调研再回用户快。

### Manus 复述模式：长任务中的 todo.md

后台 worker 执行复杂任务（≥3 步）时，会在工作目录维护一个 `todo.md`：
- 开工时创建，列出所有步骤
- 每完成一步更新，已完成的打勾
- 卡住时追加「卡住原因」
- 完成时全打勾

原理：每步更新 todo.md 将全局目标推入上下文尾部，避免 agent "lost in the middle"。这是 Manus 上下文工程的核心技巧之一（Recitation）。

Worker SOUL.md 模板见 `references/worker-SOUL.md`。

### 执行顺序（硬约束）

1. 识别任务性质（**2 句话**足够判断，禁止深入分析）
2. **大任务**：kanban_create() → 立即回复"已提交 N 个任务到后台"
3. **小任务**：直接执行 → 正常回复
4. **禁止在回复前做调研、设计、或实质性工作**——那是 worker 的事

### 拆卡方法论

复合任务拆解步骤：

1. 列出所有独立的工作单元
2. 标识依赖关系（A → B：A 完成才能做 B）
3. **独立单元**：并行 kanban_create()，不设 parents
4. **依赖单元**：kanban_create() 设 parents=[前置任务ID]
5. **汇总任务**：设 parents=[所有子任务ID]

## 已知限制与应对

| 限制 | 应对 |
|------|------|
| shell 创建卡片时 body 换行符丢失 | 用 stdin 传入 body（见辅助脚本） |
| kanban_complete() 不验证产出 | 配合验证脚本二次确认 |
| worker 崩溃后任务卡 running | 设置 stale_timeout 自动回收 |
| worker 到 max_turns 卡死 | SOUL.md 要求剩余 turns ≤5 时主动 block |
| Codex OAuth 在 Docker 中不可持久化 | OAuth token 需系统钥匙串，Docker 容器无此服务。修复：`codex login --device-auth` 后台运行（timeout=600s），token 存 `~/.codex/auth.json`（持久化 volume，重启不丢）。见 `references/codex-auth-docker.md` |
| worker 持有全部 API key | 精简 .env，最小权限原则 |
| output_path 无限制 | SOUL.md 硬性规定白名单目录 |

## 操作速查

### 创建任务（推荐方式，保留换行符）
```bash
cat > /tmp/task-body.txt << 'EOF'
TASK
type: env / code / analysis / wiki
description: 任务描述
output_path: /opt/data/workflow/wiki/done/<产出文件名>
requirements: 具体要求
EOF
cat /tmp/task-body.txt | /opt/data/scripts/kanban-create.sh "任务标题"
```

### 创建并行子任务（Python 侧）
```python
t1 = kanban_create(title="子任务A", assignee="worker", body="...")
t2 = kanban_create(title="子任务B", assignee="worker", body="...")
t3 = kanban_create(title="汇总", assignee="worker", parents=[t1.id, t2.id])
```

### 查进度
```bash
hermes kanban show <task_id>     # 状态 + 进度日志
hermes kanban list               # 全部任务一览
```

## 适用场景速查

| 场景 | delegate？ | assignee | 原因 |
|------|-----------|----------|------|
| 整理目录、搬文件 | ❌ 直接干 | — | 1 步 mv/mkdir 搞定 |
| 分析 300 个技能 | ✅ kanban | researcher | 需调研+推理 |
| 用户问现在几点 | ❌ 直接回 | — | 纯回复 |
| 跑 ORCA 计算 | ✅ kanban | compute | 可能几小时，必须后台 |
| 写 wiki 页面 | ✅ kanban | writer | 需调研+写作+验证 |
| 改一行配置 | ❌ 直接干 | — | 1 步 patch |
| 打包归档旧文件 | ❌ 直接干 | — | 1 步 tar czf |
| 组织目录重组方案 | ✅ kanban | worker | 需设计+拆卡+验证 |
| 写数据分析脚本 | ✅ kanban | code | 需编码+调试 |
| 文献综述 | ✅ kanban | researcher | 深度调研 |
| 翻译文档 | ✅ kanban | writer | 语言质量要求高 |

## 安装验证清单

- [ ] `hermes kanban init` — 初始化 kanban.db
- [ ] Kanban 配置已更新（stale_timeout=600）
- [ ] Worker profile 已创建且 .env 已精简
- [ ] Worker SOUL.md 已写入（含路径限制、block 条件、完成验证）
- [ ] 辅助脚本已创建且可执行
- [ ] 发一张测试卡验证全流程：create → dispatch → complete → 校验产出

## Skill 分享

本 skill 的分享版本（去敏、打包为 `tar.gz`、上传到 `static/skills/`、更新 skill-share 页面）见 `references/skill-sharing-workflow.md`。按流程操作即可发布。

### 分享检查清单
- [ ] 移除本地路径（`/opt/data/` → 通用路径）
- [ ] 移除 API key、token、密码
- [ ] 移除个人信息
- [ ] 协议注明 CC BY-NC-SA 4.0（禁止商用）
- [ ] 打包为 `tar.gz` 放入 `static/skills/<name>/`
- [ ] 在 `skill-share/index.md` 追加条目
- [ ] **推送前等用户说"发"或"push"**，禁止自动推送

## 常见陷阱

### 陷阱 1：Codex 在 Docker 中 bwrap 失败
Docker 容器内 `codex exec` 默认使用 bubblewrap 沙箱，但 Docker 环境不支持非特权用户命名空间。表现为 `bwrap: No permissions to create a new namespace`。修复方法：
- 使用 `codex exec --dangerously-bypass-approvals-and-sandbox`（适合简单文件编辑）
- 或直接手动用 `patch`/`write_file`/`sed` 修改——对简单改动（改一行配置、写一个文件）手动改比等 Codex 快得多

### 陷阱 2：Profile 过特化
不要为每个单一任务创建特化 profile。保持一个通用 `worker` profile 作为默认，只在有明确收益时创建特化变体（compute/code/writer/researcher）。特化 profile 的维护成本（.env、SOUL.md、config）可能超过收益。

### 陷阱 3：前后台不分离
收到任务后先调研再回复是错误的行为。正确顺序：识别意图（2句话）→ `kanban_create()` → 回复"已提交"。调研是 worker 的事，不是主 agent 的事。

### 陷阱 4：Gemini reasoning tokens 吞输出预算
Gemini 3.1 Pro 有内置推理阶段（reasoning tokens），计入 max_tokens 限制。例如 max_tokens=2000 时推理可能消耗 1500+，实际输出只剩 ~400 tokens。调用时设 max_tokens=8000 以上。简单问答用 nothinking 后缀模型（gemini-2.5-flash-nothinking）跳过推理。

## 版本历史

| 版本 | 日期 | 变化 |
|------|------|------|
| 3.0.0 | 2026-06-13 | 新增完整 setup guide、多层模型架构、安装验证清单、references/ 支持文件 |
| 2.0.0 | 2026-06-13 | 基于 Kanban 替代 delegate_task；新增前后台分离铁律、判定表、特化 profile |
| 1.0.0 | 2026-06-13 | 初版 |
