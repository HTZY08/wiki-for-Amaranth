---
name: delegate
description: 通过 Hermes Kanban 实现异步任务委派——大任务拆解后交给后台 worker 执行，前台保持响应。小任务直接干。
version: 1.0.0
author: Hermes Community
license: MIT
metadata:
  hermes:
    tags: [delegate, async, kanban, orchestration, workflow]
    related_skills: [kanban-orchestrator, background-task-routing]
---

# Delegate — 异步任务委派系统

## 概述

基于 Hermes Kanban 的异步任务处理架构。将大任务拆解为子任务，通过 `kanban_create(assignee=<profile>)` 派发给对应的特化 profile 执行。主 agent 立即回复用户，不阻塞。

## 架构

```
用户 → 主 Agent（前台）
         │ kanban_create() × N → 立即返回
         ↓
      Kanban Queue (SQLite)
         │ dispatcher（Hermes gateway 内部）每 N 秒轮询
         ↓
      worker profile（后台独立进程，完整 Hermes 工具集）
         │ 读卡片 → 执行 → 写产出
         │ kanban_comment() 记录进度
         │ kanban_complete() 完成
```

## 前置条件

- Hermes Agent（版本 ≥ 0.14.0）
- Kanban 已初始化（`hermes kanban init`）
- 至少一个 worker profile（`hermes profile create worker --clone`）

## 配置

### 1. Kanban 参数（`~/.hermes/config.yaml`）

```yaml
kanban:
  dispatch_in_gateway: true
  dispatch_interval_seconds: 5        # Dispatcher 轮询间隔
  failure_limit: 3                     # 失败重试次数
  orchestrator_profile: 'default'     # 你的主 profile
  default_assignee: 'worker'          # 默认 worker profile
  max_in_progress_per_profile: 3      # 并发上限
  dispatch_stale_timeout_seconds: 600 # 任务卡死回收时间（10分钟）
```

### 2. Worker Profile SOUL.md

Worker profile 的 SOUL.md（`~/.hermes/profiles/worker/SOUL.md`）需包含：

- 核心规则：读卡片 → 执行 → 写产出 → 完成
- 不交互：没有用户，不要调用 `clarify()`
- 每步用 `kanban_comment()` 记录进度
- 完成前确认产出文件存在
- output_path 必须在白名单目录下

### 3. Worker .env（最小权限）

Worker profile 的 `.env` 应精简到仅保留必要的 API key，移除所有非必需的 key。

## 行为规则

### 何时走 Kanban（大任务）
- 3+ 步骤才能完成
- 需要调研/搜索/分析
- 需要持久产出（写文件、跑计算）
- 用户明确说"后台跑"

### 何时直接干（小任务）
- 1 步脚本能搞定
- 纯回复类
- 预估 < 5 秒

### 执行顺序
1. 识别任务性质（2 句话判断，禁止深入分析）
2. 大任务：`kanban_create()` → 立即回复"已提交"
3. 小任务：直接执行 → 正常回复
4. 禁止在回复前做调研

## Profile 模板

可根据需要创建特化 profile，建议的分工：

| Profile | 主模型 | 副模型 | 专精 |
|---------|-------|-------|------|
| worker | 通用 | — | 不明确分类的任务 |
| compute | 执行模型 | 分析模型 | 计算化学 |
| code | 执行模型 | 架构模型 | 编码/debug |
| writer | 写作模型 | 执行模型 | 文档/翻译 |
| researcher | 分析模型 | 执行模型 | 文献/深度研究 |

## 已知限制

| 限制 | 应对 |
|------|------|
| Shell 传参时 body 换行符丢失 | 用 stdin 传入 body |
| kanban_complete() 不验证产出 | 配合验证脚本二次确认 |
| worker 崩溃后任务卡 running | 设置 stale_timeout 自动回收 |
| worker 到 max_turns 卡死 | SOUL.md 要求剩余 turns ≤5 时主动 block |
