# 特化 Profile 模板

本目录包含 5 个 profile 的 SOUL.md 模板，复制到对应 profile 目录即可使用。

## 安装

```bash
# 创建 profile
hermes profile create worker --clone
hermes profile create compute --clone
hermes profile create code --clone
hermes profile create writer --clone
hermes profile create researcher --clone

# 复制 SOUL.md
cp references/worker-SOUL.md ~/.hermes/profiles/worker/SOUL.md
cp references/compute-SOUL.md ~/.hermes/profiles/compute/SOUL.md
# ... 以此类推
```

## Profile 一览

| Profile | 主模型 | 副模型 | 专精 |
|---------|-------|-------|------|
| worker | 通用 | — | 不明确分类的任务 |
| compute | DeepSeek V4 Flash | Gemini 3.1 Pro | ORCA/xtb/docking |
| code | DeepSeek V4 Flash | Claude Sonnet | 脚本/debug/架构 |
| writer | Claude Sonnet | DeepSeek V4 Flash | 文档/翻译/润色 |
| researcher | Gemini 3.1 Pro | DeepSeek V4 Flash | 文献/深度分析 |

## 安全

每个 profile 的 .env 需精简到仅保留必要的 API key。
